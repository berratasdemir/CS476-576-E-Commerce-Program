import 'package:flutter/material.dart';
import 'package:untitled/components/my_textfield.dart';


class ChangePasswordPage extends StatelessWidget{
  ChangePasswordPage({super.key});
  final oldpasswordController = TextEditingController();
  final newpasswordController = TextEditingController();


  @override
  Widget build(BuildContext context){
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.grey[300],
        body: SafeArea(
            child: Center(

              child: SingleChildScrollView(
                child: Column(
                  children:  [
                    //const SizedBox(height: 10),
                    const Icon(
                        Icons.lock,
                        size: 100
                    ),
                    const SizedBox(height: 30),


                    MyTextField(
                      controller: oldpasswordController,
                      hintText: 'Enter your current password',
                      obscureText: true,
                    ),

                    const SizedBox(height: 10),

                    //password
                    MyTextField(
                      controller: newpasswordController,
                      hintText: 'Enter your new password',
                      obscureText: true,
                    ),

                    const SizedBox(height: 10),

                    //password
                    MyTextField(
                      controller: newpasswordController,
                      hintText: 'Enter your new password again',
                      obscureText: true,
                    ),

                    MaterialButton(onPressed: (){},
                    color: Colors.blue,
                    child: const Text("Change Password"),)






                  ],
                ),
              ),
            )
        )
    );
  }
}

